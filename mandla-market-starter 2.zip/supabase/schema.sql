-- Mandla Market starter schema.
-- Run in Supabase SQL Editor only after reviewing and configuring your project.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  role text not null default 'buyer' check (role in ('buyer','seller','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.seller_applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  full_name text not null,
  phone text not null,
  seller_type text not null default 'Individual',
  area text not null,
  about text,
  status text not null default 'pending' check (status in ('pending','approved','rejected','suspended')),
  created_at timestamptz not null default now()
);

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  name_en text not null,
  name_hi text,
  slug text unique not null,
  active boolean not null default true
);

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id),
  category_id uuid references public.categories(id),
  title text not null,
  description text,
  price numeric(12,2),
  condition text,
  area text,
  status text not null default 'pending' check (status in ('pending','published','rejected','sold','removed')),
  created_at timestamptz not null default now()
);

create table if not exists public.listing_images (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  image_url text not null,
  sort_order int not null default 0
);

create table if not exists public.favorites (
  user_id uuid not null references public.profiles(id) on delete cascade,
  listing_id uuid not null references public.listings(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id, listing_id)
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid references public.listings(id) on delete set null,
  reporter_id uuid references public.profiles(id) on delete set null,
  reason text not null,
  details text,
  status text not null default 'open',
  created_at timestamptz not null default now()
);

-- Enable RLS. Policies below are deliberately conservative.
alter table public.profiles enable row level security;
alter table public.seller_applications enable row level security;
alter table public.categories enable row level security;
alter table public.listings enable row level security;
alter table public.listing_images enable row level security;
alter table public.favorites enable row level security;
alter table public.reports enable row level security;

-- Public can read active categories and published listings.
create policy "Public read active categories" on public.categories for select using (active = true);
create policy "Public read published listings" on public.listings for select using (status = 'published');

-- Authenticated users can create their own seller application.
create policy "Users submit own seller application" on public.seller_applications
for insert to authenticated with check (auth.uid() = user_id);

-- Users can read their own profile and application.
create policy "Users read own profile" on public.profiles
for select to authenticated using (auth.uid() = id);
create policy "Users read own seller application" on public.seller_applications
for select to authenticated using (auth.uid() = user_id);

-- NOTE: Admin approval, seller listing creation, storage policies and admin-only
-- policies must be added using a trusted server-side admin role / secure claims.
-- Do not let clients update their own role or approval status.
-- Do not expose the Supabase service_role key in browser code.
