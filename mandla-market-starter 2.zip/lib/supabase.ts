import { createClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

// The site can run as a visual demo without credentials.
// Add Supabase credentials to .env.local to enable backend integration.
export const supabase = url && key ? createClient(url, key) : null;
