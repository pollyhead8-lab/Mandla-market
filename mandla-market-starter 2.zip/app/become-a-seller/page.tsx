"use client";
import { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { supabase } from "@/lib/supabase";

export default function BecomeSeller(){
 const [sent,setSent]=useState(false); const [error,setError]=useState("");
 async function submit(e:React.FormEvent<HTMLFormElement>){
  e.preventDefault();setError("");
  const f=new FormData(e.currentTarget);
  const payload={full_name:f.get("name"),phone:f.get("phone"),seller_type:f.get("type"),area:f.get("area"),about:f.get("about"),status:"pending"};
  if(!supabase){setError("Demo mode: connect Supabase using .env.local before accepting real applications.");return;}
  const {error}=await supabase.from("seller_applications").insert(payload);
  if(error){setError(error.message);return;} setSent(true);
 }
 return <><Header/><main className="container"><div className="form-card"><div className="eyebrow">JOIN THE LOCAL MARKET</div><h1 className="page-title" style={{marginTop:10}}>Become a seller</h1><p className="muted">Apply to sell on Mandla Market. Our admin team reviews every application before approval.</p>{sent?<div className="notice">Application submitted! Your seller status is pending admin review.</div>:<form onSubmit={submit}>
  <div className="field"><label>Full name / पूरा नाम</label><input name="name" required placeholder="Your full name"/></div>
  <div className="field"><label>Mobile number / मोबाइल नंबर</label><input name="phone" required inputMode="tel" pattern="[0-9+ ]{10,15}" placeholder="10-digit mobile number"/></div>
  <div className="field"><label>Seller type / विक्रेता का प्रकार</label><select name="type"><option>Individual</option><option>Shop / Business</option><option>Service provider</option></select></div>
  <div className="field"><label>Area in Mandla / क्षेत्र</label><input name="area" required placeholder="Your area or locality"/></div>
  <div className="field"><label>What do you plan to sell? / आप क्या बेचना चाहते हैं?</label><textarea name="about" rows={3} placeholder="Tell us a little about your products or services"/></div>
  <div className="notice">Submitting an application does not automatically give permission to publish ads. Seller approval is required.</div>
  {error&&<p style={{color:"#A33",fontSize:13}}>{error}</p>}
  <button className="btn btn-dark" style={{width:"100%",marginTop:16}}>Submit seller application →</button>
 </form>}</div></main><Footer/></>
}
