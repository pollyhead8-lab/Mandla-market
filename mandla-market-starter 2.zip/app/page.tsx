import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const categories = [
  ["📱","Mobiles & Tablets"],["🚗","Cars & Bikes"],["🛋️","Furniture"],
  ["💻","Electronics"],["🏠","Property"],["👕","Fashion"],
  ["📚","Books & Education"],["🔧","Services"],["🧺","Home & Living"],
  ["🎮","Sports & Hobbies"],["🐄","Agriculture"],["✨","Other"]
];
const products = [
  {emoji:"📱",name:"Smartphone",price:"₹12,000",tag:"Electronics"},
  {emoji:"🛋️",name:"3-seater sofa",price:"₹8,500",tag:"Furniture"},
  {emoji:"🚲",name:"City bicycle",price:"₹3,200",tag:"Vehicles"},
  {emoji:"💻",name:"Laptop",price:"₹18,000",tag:"Electronics"}
];
export default function Home(){
 return <><Header/><main className="container">
  <section className="hero">
   <div><div className="eyebrow">MANDLA'S LOCAL MARKETPLACE</div><h1>Buy & sell anything in Mandla.</h1><p>Discover great local deals, connect with nearby sellers and give your pre-loved things a new home.</p>
    <form action="/listings" className="searchbox"><input name="q" placeholder="Search mobiles, bikes, furniture..." aria-label="Search listings"/><button className="btn btn-dark">Search →</button></form>
    <div style={{display:"flex",gap:18,marginTop:18,color:"#68737E",fontSize:12}}><span>✓ Local sellers</span><span>✓ Admin-reviewed listings</span></div>
   </div>
   <div className="hero-art"><div className="float-tag float-one">📍 Only in Mandla</div><div className="market-card"><div className="circle">🛍️</div><h3>Your next great find.</h3><p>Local deals are closer than you think.</p><div style={{marginTop:19}} className="pill">APNA SHEHER. APNA BAZAAR.</div></div><div className="float-tag float-two">✨ Buy local. Sell local.</div></div>
  </section>
  <section className="section" id="categories"><div className="section-head"><div><h2>Explore categories</h2><div className="muted">Find what you need, right here in Mandla.</div></div><Link href="/listings" className="muted">View all →</Link></div>
   <div className="categories">{categories.map(([icon,name])=><Link className="category" href={`/listings?category=${encodeURIComponent(name)}`} key={name}><div className="cat-icon">{icon}</div><strong>{name}</strong></Link>)}</div>
  </section>
  <section className="section"><div className="section-head"><div><h2>Fresh recommendations</h2><div className="muted">A few examples of what you can find here.</div></div><Link href="/listings" className="muted">Browse all →</Link></div>
   <div className="listing-grid">{products.map(p=><article className="product" key={p.name}><div className="product-img">{p.emoji}</div><div className="product-body"><span className="pill">SAMPLE LISTING</span><p className="product-title">{p.name}</p><div className="price">{p.price}</div><div className="product-meta">📍 Mandla · {p.tag}</div></div></article>)}</div>
  </section>
  <section className="cta"><div><h2>Have something to sell?</h2><p>Apply to become a seller and reach buyers across Mandla.</p></div><Link href="/become-a-seller" className="btn btn-gold">Start selling →</Link></section>
 </main><Footer/></>
}
