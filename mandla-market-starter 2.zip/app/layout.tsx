import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Mandla Market | Apna Sheher. Apna Bazaar.",
  description: "Buy and sell locally in Mandla, Madhya Pradesh.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
