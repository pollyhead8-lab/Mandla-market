"use client";
import Link from "next/link";
import { useState } from "react";

export default function Header() {
  const [lang, setLang] = useState<"en"|"hi">("en");
  const hi = lang === "hi";
  return <>
    <div className="topbar"><div className="container" style={{display:"flex",justifyContent:"space-between"}}><span>📍 {hi ? "मंडला, मध्य प्रदेश" : "Mandla, Madhya Pradesh"}</span><span>{hi ? "आपका अपना स्थानीय बाज़ार" : "Your own local marketplace"}</span></div></div>
    <header className="container nav">
      <Link href="/" className="brand">MANDLA <span>MARKET.</span></Link>
      <nav className="navlinks"><Link href="/listings">{hi?"खरीदें":"Buy"}</Link><Link href="/become-a-seller">{hi?"बेचें":"Sell"}</Link><a href="#categories">{hi?"श्रेणियाँ":"Categories"}</a></nav>
      <div style={{display:"flex",gap:9,alignItems:"center"}}>
        <button className="btn btn-outline" style={{padding:"10px 12px"}} onClick={()=>setLang(hi?"en":"hi")}>{hi?"EN":"हिं"}</button>
        <Link className="btn btn-gold" href="/become-a-seller">{hi?"+ विज्ञापन डालें":"+ Post Ad"}</Link>
      </div>
    </header>
  </>;
}
